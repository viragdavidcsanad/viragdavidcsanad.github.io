<div class="services_page">
  <div class="services_page_message">
    <p>Just fill out the form below or email me directly, I will reply you as soon as possible, normally i reply in less than 1 hour in office timing.
    </p>
    <p>Your privacy is the most important thing for me, so please fell free to fill the form, your information will not be shared with anyone.
    </p>
  </div>
  <div class="left_section">
    <p class="easy-under-construction-promo-box-header">Need Help in Development of your Dream website?
    </p>
    <div class="description_of_service">Please feel free to contact me any time whenever you need web development & designing or customization Service. I am always here for your help 24/7.
      <br>	
      <div align="center">
        <br>		
        <strong>Email me directly at: 
          <a href="mailto:abbasahmed50@gmail.com">abbasahmed50@gmail.com
          </a>
        </strong>
        <br>	
        OR
        <br>		
        <strong>
          Fill out the form	I will get back to you as soon as possible.
        </strong>				
      </div>	
    </div>
    <div class="aboutme_box">
      <img class="profile_pic" src="<?php echo plugin_dir_url(__FILE__) . "templates/images/profile-min.png"; ?>">
      ✨
      <strong>A Little About Me:
      </strong> My name is Abbas, I am a wordpress pro developer, I have developed my own plugins for wordpress plugins repository and premium wordpress themes for sale. You can gauge my coding quality from it. I am serving Wordpress community since 2014. With +8 years experience i am here to do something very special for you, my goal here is very simple "100% customer satisfaction". Most of my customers are permanently working with me. I want you to be one of them. My request is to work with me just once. Coming back again and again will be your choice :)
    </div>
    <ul class="bullets">
      <li>
        <strong>Overall Rating: 5.0
        </strong> 
        <span class="dashicons dashicons-star-filled">
        </span>
        <span class="dashicons dashicons-star-filled">
        </span>
        <span class="dashicons dashicons-star-filled">
        </span>
        <span class="dashicons dashicons-star-filled">
        </span>
        <span class="dashicons dashicons-star-filled">
        </span> (783 reviews)		
      </li>
      <li>
        <strong>Number of clients:
        </strong> 500+	
      </li>	
      <li>
        <strong>Completed websites:
        </strong> 400+	
      </li>	
      <li>
        <strong>For portfolio: 
        </strong>
        Fill out the form and i will send you the list.
      </li>	
    </ul>				
  </div>
  <div class="right_section">
    <iframe src="https://docs.google.com/forms/d/e/1FAIpQLScwD36A4JcHE_klmNu_mKefhI85w4LtRC3ytcmE8qdMmb_RqA/viewform?embedded=true" width="100%" height="1000" frameborder="0" marginheight="0" marginwidth="0">Loading…
    </iframe>		
  </div>
  <div class="customer_reviews">
    <h2>Customer reviews
    </h2>
    <img class="reviews" src="<?php echo plugin_dir_url(__FILE__) . "templates/images/reviews.png"; ?>">
  </div>	
</div>