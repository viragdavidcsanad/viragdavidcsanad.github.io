<?php
	// Silence is golden.
	// Hide file structure from users on unprotected servers.