<?php 
function displayDefaultComingSoonPage()
{
displayComingSoonPage(trim(get_bloginfo('title')).' is coming soon', get_bloginfo('url'), 'is coming soon');
}
function displayComingSoonPage($title, $headerText, $bodyText)
{
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>
      <?php echo $title; ?>
    </title>
    <style type="text/css">
      #Layer_1 {
        width: 20%;
      }
      .easyuc {
        text-align: center;
      }
      h1 {
        font-family: monospace;
      }
      h2 {
        font-size: 24px;
        font-family: monospace;
      }
      html, body {
        background: #ff9a00;
      }
      @media only screen and (max-width: 980px) {
        #Layer_1 {
          width: 50% !Important;
        }
        h1 {
          font-size: 45px !IMPORTANT;
          margin-top: 10% !IMPORTANT;
          font-family: monospace;
        }
        h2 {
          font-size: 42px !IMPORTANT;
        }
      }
    </style>
    <?php
echo "<style>";
echo "html, body {";
echo "background:" . $bgcolor = stripslashes(get_option('easyunderConstructionbgcolor_two')) . "!Important";	
echo "}";
echo "</style>";
?>			
  </head>
  <body>		
    <div class="easyuc">
      <h1>
        <?php echo get_bloginfo('title'). " is"; ?>
      </h1>
      <h1>Under Construction
      </h1>
      <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" viewBox="0 0 240 330" xml:space="preserve">
        <defs>
          <mask id="mask1" x="0" y="0" width="240" height="330">
            <rect xmlns="http://www.w3.org/2000/svg" x="0" y="0" width="240" height="330" style="fill: #ffffff"/>
          </mask>
        </defs>
        <defs id="main_object33"> 
        </defs>
        <defs id="fireAni"> 
        </defs>
        <g id="main_object_masked" style="mask: url(#mask1)">
          <g id="main_object" transform="matrix(1, 0, 0, 1, 0, -0.009108843491347808)">
            <g id="rocketWithFire_holder" transform="translate(-13 0)">
              <g id="rocketWithFire" transform="translate(16.80000000000001 7.200000000000642)">
                <g id="burning">
                  <polygon fill="#b5bbbe" points="114.826,162 132.238,162 160.959,333 85.921,333  "/>
                  <polygon id="fireFade" fill="#FFFFFF" points="120.863,162 103.124,333 145.221,333 126.198,162  "/>
                </g>
                <g>	
                  <path fill="#FBD254" d="M138.229,180.432c0,18.126-11.172,32.819-14.541,32.819c-4.607,0-14.541-14.692-14.541-32.819     c0-18.125,9.753-21.09,14.541-21.09C129.895,159.341,138.229,162.307,138.229,180.432z"/>
                  <path fill="#FF0C00" d="M134.102,175.992c0,14.31-8.188,25.91-10.662,25.91c-3.375,0-10.661-11.604-10.661-25.91     c0-14.308,7.151-16.65,10.661-16.65C127.99,159.341,134.102,161.684,134.102,175.992z"/>
                  <path id="fire" fill="#FFF2CD" d="M134.102,175.992c0,14.31-8.188,25.91-10.662,25.91c-3.375,0-10.661-11.604-10.661-25.91     c0-14.308,7.151-16.65,10.661-16.65C127.99,159.341,134.102,161.684,134.102,175.992z"/>
                  <path opacity="0.1" enable-background="new    " d="M123.688,159.341c6.207,0,14.541,2.966,14.541,21.091     c0,18.125-11.172,32.818-14.541,32.818"/>
                </g>
                <g id="rocket">
                  <path fill="#6D0008" d="M106.072,170.469c-8.504,0.785-5.011-15.544-5.011-15.544l8.84-4.925h26.226l8.779,4.925     c0,0,3.99,16.419-4.904,15.151C128.534,168.441,118.679,169.307,106.072,170.469z"/>
                  <path fill="#EDECE7" d="M123,29.924c0,0-12.379-1.871-23.131,25.216c0,0-33.549,85.859,8.479,108.859H123V29.924z"/>
                  <path fill="#6D0008" d="M123,156h16.318l5.586-0.499c0,0,4.128,15.753-5.258,14.243c-5.201-0.837-9.043-0.825-15.166-0.799"/>
                  <path fill="#F4F3EF" d="M123,29.924c0,0,12.33-1.871,23.057,25.216c0,0,33.451,85.859-8.479,108.859H123V29.924z"/>
                  <path fill="#C73937" d="M123,55V29.924c0,0-12.368-2.196-23.12,24.892"/>
                  <path fill="#E54545" d="M122,55V29.924c0,0,12.876-2.196,24.066,24.892"/>
                  <rect x="94" y="132" fill="#3B515E" width="60" height="7"/>
                  <circle fill="#A29B95" cx="123.311" cy="92.966" r="15.162"/>
                  <path opacity="0.1" enable-background="new    " d="M122.624,29.924c0,0,12.694-1.871,23.421,25.216     c0,0,33.207,85.859-8.469,108.859h-14.952c0,0,18.885-6.049,23.585-34.055c4.256-25.357-0.564-57.072-9.045-78.472     C129.716,32.676,122.624,29.924,122.624,29.924z"/>
                  <path fill="#88171A" d="M107.941,168.118c-6.083,1.095-5.934-8.777-5.934-8.777c5.202,2.011,27.921,4.714,41.8,0.036     c0.416,0.094,0.783,9.696-6.82,8.645C127.471,166.707,118.958,166.135,107.941,168.118z"/>
                  <g>
                    <g>
                      <circle id="SVGID_1_" fill="#9FCFD1" cx="123.168" cy="93.002" r="12.4"/>
                    </g>
                    <g>
                      <g>
                        <g>
                          <defs>
                            <circle id="SVGID_2_" cx="123.168" cy="93.002" r="12.4"/>
                          </defs>
                          <clipPath id="SVGID_3_">
                            <use xlink:href="#SVGID_2_" overflow="visible"/>
                          </clipPath>
                          <path clip-path="url(#SVGID_3_)" fill="#9FCFD1" d="M126.643,79.577c0,0,10.643,13.359-0.709,26.6         c0,0,7.094-1.419,10.404-7.211c0,0,3.546-6.089-0.77-12.845C135.568,86.121,133.736,82.414,126.643,79.577z"/>
                        </g>
                      </g>
                    </g>
                  </g>
                  <g>
                    <g>
                      <g>
                        <g>
                          <defs>
                            <circle id="SVGID_4_" cx="123.168" cy="93.002" r="12.4"/>
                          </defs>
                          <clipPath id="SVGID_6_">
                            <use xlink:href="#SVGID_4_" overflow="visible"/>
                          </clipPath>
                          <path clip-path="url(#SVGID_6_)" fill="#CAE6E9" d="M126.643,79.577c0,0,10.643,13.359-0.709,26.6         c0,0,7.094-1.419,10.404-7.211c0,0,3.546-6.089-0.77-12.845C135.568,86.121,133.736,82.414,126.643,79.577z"/>
                        </g>
                      </g>
                    </g>
                  </g>
                  <rect x="94" y="141" fill="#3B515E" width="60" height="3"/>
                  <path fill="#C73937" d="M87.182,102.276c0,0-27.156,28.55-14.389,64.193c0,0,1.773,2.661,4.256-0.354     c0,0,10.817-14.541,20.393-12.413C97.442,153.702,96.427,93.231,87.182,102.276z"/>
                  <path fill="#E54545" d="M92.686,106.496c-0.972-4.633-3.192-6.481-5.504-4.22c0,0-27.156,28.55-14.389,64.193     c0,0,1.773,2.661,4.256-0.354C77.049,166.115,66.586,137.389,92.686,106.496z"/>
                  <path fill="#C73937" d="M159.439,102.276c0,0,27.156,28.55,14.388,64.193c0,0-1.772,2.661-4.257-0.354     c0,0-10.817-14.541-20.395-12.413C149.178,153.702,150.193,93.231,159.439,102.276z"/>
                  <path fill="#E54545" d="M153.936,106.496c0.975-4.633,3.191-6.481,5.504-4.22c0,0,27.156,28.55,14.39,64.193     c0,0-1.771,2.661-4.259-0.354C169.57,166.115,180.034,137.389,153.936,106.496z"/>
                  <circle fill="#CAE6E9" cx="120.042" cy="88.433" r="3.27"/>
                  <path fill="#C73937" d="M121.736,113.802c0,0-11.708-1.044,0.06,59.524c0.935,3.684,3.229,4.609,4.56,0     C130.189,139.042,132.555,110.965,121.736,113.802z"/>
                  <path fill="#E54545" d="M122.624,119.181c0,0,0.944-2.01,1.3,47.17c0.253,3.088,0.151,6.256,1.301-0.119     C127.471,145.427,127.456,118.1,122.624,119.181z"/>
                  <circle fill="#939393" cx="122.602" cy="66.366" r="4.88"/>
                  <g>
                    <g>
                      <circle id="SVGID_5_" fill="#9FCFD1" cx="122.557" cy="66.378" r="3.992"/>
                    </g>
                    <g>
                      <g>
                        <g>
                          <defs>
                            <circle id="SVGID_7_" cx="122.557" cy="66.378" r="3.992"/>
                          </defs>
                          <clipPath id="SVGID_8_">
                            <use xlink:href="#SVGID_7_" overflow="visible"/>
                          </clipPath>
                          <path clip-path="url(#SVGID_8_)" fill="#9FCFD1" d="M123.674,62.057c0,0,3.426,4.3-0.229,8.563c0,0,2.283-0.457,3.349-2.321         c0,0,1.144-1.96-0.247-4.135C126.547,64.163,125.958,62.969,123.674,62.057z"/>
                        </g>
                      </g>
                    </g>
                  </g>
                  <g>
                    <g>
                      <g>
                        <g>
                          <defs>
                            <circle id="SVGID_9_" cx="122.557" cy="66.378" r="3.992"/>
                          </defs>
                          <clipPath id="SVGID_10_">
                            <use xlink:href="#SVGID_9_" overflow="visible"/>
                          </clipPath>
                          <path clip-path="url(#SVGID_10_)" fill="#CAE6E9" d="M123.674,62.057c0,0,3.426,4.3-0.229,8.563c0,0,2.283-0.457,3.349-2.321         c0,0,1.144-1.96-0.247-4.135C126.547,64.163,125.958,62.969,123.674,62.057z"/>
                        </g>
                      </g>
                    </g>
                  </g>
                </g>
              </g>
            </g>
            <g id="smoke">
              <circle xmlns="http://www.w3.org/2000/svg" id="cloud1" fill="#b5bbbe" cx="29%" cy="95%" r="34" transform="scale(1.0000000000000033 1.0000000000000033)"/>
              <circle xmlns="http://www.w3.org/2000/svg" id="cloud2" fill="#b5bbbe" cx="45%" cy="92%" r="35" transform="scale(1.068 1.068)"/>
              <circle xmlns="http://www.w3.org/2000/svg" id="cloud3" fill="#b5bbbe" cx="65%" cy="95%" r="40" transform="scale(1.0220000000000065 1.0220000000000065)"/>
              <circle xmlns="http://www.w3.org/2000/svg" id="cloud4" fill="#b5bbbe" cx="84%" cy="102%" r="34" transform="scale(1.0000000000000033 1.0000000000000033)"/>
              <circle xmlns="http://www.w3.org/2000/svg" id="cloud5" fill="#b5bbbe" cx="15%" cy="99%" r="33" transform="scale(1.0220000000000065 1.0220000000000065)"/>
            </g>
          </g>
        </g>
        <style type="text/css">
          <![CDATA[
          @keyframes flameBig {
            0%        {
              opacity: .5}
            50%  {
              opacity: 1}
            100% {
              opacity: .5}
          }
          #fireFade {
            animation: flameBig .5s ease infinite;
          }
          @keyframes flameBig {
            0%        {
              opacity: .5}
            50%  {
              opacity: 1}
            100% {
              opacity: .5}
          }
          #fireFade {
            animation: flameBig .5s ease infinite;
          }
          @keyframes fireBig {
            0%        {
              opacity: 1}
            30%  {
              opacity: .7}
            50%  {
              opacity: .8}
            70%  {
              opacity: .6}
            100% {
              opacity: .9}
          }
          #fire {
            animation: fireBig .5s ease infinite;
          }
          #smoke{
            animation: takeoffSmoke 1.5s ease;
          }
          @keyframes takeoffSmoke {
            from{
              transform: translateY(450px);
            }
            to {
              transform: translateY(0px)
            }
          }
          ]]></style>
        <script type="text/javascript">
          <![CDATA[
            function startAnimation(){
              null==Interval&&(Interval=setInterval(animate,30))}
            function stopAnimation(){
            null!=Interval&&(clearInterval(Interval),Interval=null)}
            function animate(){
            ScaleObj+=Speed,ScaleObj2+=Speed2,ScaleObj3+=Speed3,ScaleObj>=1.03&&az&&(Speed=-.001,az=!1),1>=ScaleObj&&!az&&(Speed=.001,az=!0),ScaleObj2>=1.07&&az2&&(Speed2=-.002,az2=!1),1.02>=ScaleObj2&&!az2&&(Speed2=.002,az2=!0),ScaleObj3>=1.08&&az3&&(Speed3=-.001,az3=!1),1.01>=ScaleObj3&&!az3&&(Speed3=.001,az3=!0),CP.setAttribute("transform","scale("+ScaleObj+" "+ScaleObj+")"),CP2.setAttribute("transform","scale("+ScaleObj2+" "+ScaleObj2+")"),CP3.setAttribute("transform","scale("+ScaleObj3+" "+ScaleObj3+")"),CP4.setAttribute("transform","scale("+ScaleObj+" "+ScaleObj+")"),CP5.setAttribute("transform","scale("+ScaleObj3+" "+ScaleObj3+")"),Angle+=AngSpeed,mainAni>0&&(mainAni+=(-.1-mainAni)/5,main_object.setAttribute("transform","matrix(1, 0, 0, 1, 0, "+mainAni+")")),rocket.setAttribute("transform","translate("+(100*ScaleObj2-90)+" "+(100*ScaleObj3-95)+")")}
            var Angle=0,AngSpeed=.25,Speed=.01,Speed2=.01,Speed3=.01,ScaleObj=1,ScaleObj2=1.05,ScaleObj3=1.07,az=!0,az2=!0,az3=!0,CP=document.getElementById("cloud1"),CP2=document.getElementById("cloud2"),CP3=document.getElementById("cloud3"),CP4=document.getElementById("cloud4"),CP5=document.getElementById("cloud5"),rocket=document.getElementById("rocketWithFire"),main_object=document.getElementById("main_object"),mainAni=350,fire=document.getElementById("fire"),firBurnAnimation=["scale(1.0, 1.0) translate(-0 -0)","scale(1.005, 1.005) translate(-0.5 -0.5)","scale(1.01, 1.01) translate(-1 -1)","scale(1.01, 1.015) translate(-1.5 -1.5)","scale(1.02, 1.02) translate(-2 -2)","scale(1.025, 1.025) translate(-2.5 -2.5)","scale(1.03, 1.03) translate(-3 -3)","scale(1.035, 1.035) translate(-3.5 -3.5)","scale(1.04, 1.04) translate(-4 -4)","scale(1.05, 1.05) translate(-5 -5)"],fir_k=0,aniFir=1,Interval=null;
             startAnimation();
            ]]>
        </script>
      </svg>			
      <h2>
        <?php echo "We will be back soon."; ?>
      </h2>
    </div>
  </body>
</html>
<?php 
}
/* EOF */
?>