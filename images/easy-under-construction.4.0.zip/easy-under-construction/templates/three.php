<?php 
function displayDefaultComingSoonPage()
{
displayComingSoonPage(trim(get_bloginfo('title')).' is coming soon', get_bloginfo('url'), 'is coming soon');
}
function displayComingSoonPage($title, $headerText, $bodyText)
{
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>
      <?php echo $title; ?>
    </title>
    <style type="text/css">
      .easyuc img {
        width: 36%;
      }
      .easyuc {
        text-align: center;
      }
      h1 {
        font-family: monospace;
      }
      h2 {
        font-size: 24px;
        font-family: monospace;
      }
      html, body {
        background: #ff9a00;
      }
      @media only screen and (max-width: 980px) {
        .easyuc img {
          width: 100% !important;
        }
        h1 {
          font-size: 45px !IMPORTANT;
          margin-top: 10% !IMPORTANT;
          font-family: monospace;
        }
        h2 {
          font-size: 42px !IMPORTANT;
        }
      }
    </style>
    <?php
echo "<style>";
echo "html, body {";
echo "background:" . $bgcolor = stripslashes(get_option('easyunderConstructionbgcolor_three')) . "!Important";	
echo "}";
echo "</style>";
?>			
  </head>
  <body>		
    <div class="easyuc">
      <h1>
        <?php echo get_bloginfo('title'). " is"; ?>
      </h1>
      <img src="<?php echo plugin_dir_url(__FILE__) . "images/ucthree.png"; ?>">			
      <h2>
        <?php echo "We will be back soon."; ?>
      </h2>
    </div>
  </body>
</html>
<?php 
}
/* EOF */
?>