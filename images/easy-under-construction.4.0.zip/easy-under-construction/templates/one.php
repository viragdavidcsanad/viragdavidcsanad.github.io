<?php 
function displayDefaultComingSoonPage()
{
displayComingSoonPage(trim(get_bloginfo('title')).' is coming soon', get_bloginfo('url'), 'is coming soon');
}
function displayComingSoonPage($title, $headerText, $bodyText)
{
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>
      <?php echo $title; ?>
    </title>
    <style type="text/css">
      .easyuc {
        text-align: center;
      }
      #Layer_1 {
        width: 50%;
      }
      html, body {
        background: antiquewhite;
      }
      h1 {
        font-family: monospace;
      }
      @media only screen and (max-width: 980px) {
        #Layer_1 {
          width: 100% !Important;
        }
        h1 {
          font-size: 45px !IMPORTANT;
          margin-top: 10% !IMPORTANT;
        }
      }
    </style>
    <?php
echo "<style>";
echo "html, body {";
echo "background:" . $bgcolor = stripslashes(get_option('easyunderConstructionbgcolor')) . "!Important";	
echo "}";
echo "</style>";
?>			
  </head>
  <body>		
    <div class="easyuc">
      <h1>
        <?php echo get_bloginfo('title'). " is currently"; ?>
      </h1>
      <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Layer_1" viewBox="0 0 240 310" xml:space="preserve">
        <g>
          <polygon fill="#DE9D03" points="140,128.042 137.5,152.917 147.5,153.667 149.25,128.667  "/>
          <polygon fill="#9B752A" points="139.334,135.417 139.166,137.5 148.5,138.333 148.666,136.167  "/>
          <polyline fill="#AA7535" points="149.25,128.667 150.125,129.292 148.5,152.167 147.5,153.667 149.25,128.667  "/>
        </g>
        <g>
          <polygon fill="#DE9D03" points="90,122.042 87.5,146.917 97.5,147.667 99.25,122.667  "/>
          <polygon fill="#9B752A" points="89.333,129.417 89.167,131.5 98.5,132.333 98.667,130.167  "/>
          <polyline fill="#AA7535" points="99.25,122.667 100.125,123.292 98.5,146.167 97.5,147.667 99.25,122.667  "/>
        </g>
        <g>
          <path opacity="0.25" d="M100.167,200.167c0.11,1.505-3.646,3.11-15.182,3.771c-9.692,0.558-12.365-0.813-12.109-1.461   c0.826-2.09,3.156-2.346,8.467-2.813C92.853,198.654,100.056,198.662,100.167,200.167z"/>
          <path opacity="0.5" fill="#050505" d="M88.917,201.833c-0.667,2.667-3.219,2.291-5.979,2.146   c-7.021-0.369-10.063-0.209-9.688-2.125c0.178-0.912,2.481-0.742,7.083-0.742C84.936,201.111,89.142,200.932,88.917,201.833z"/>
          <polygon fill="#F9CB42" points="81.666,138 73,203.333 84.333,204 92.166,138.5  "/>
          <polyline fill="#EAAE02" points="84.333,204 86,201.333 93.333,140.333 92.166,138.5  "/>
          <polygon fill="#E8AC25" points="81.75,149.333 76.333,196.167 77,196.167 83.333,147.5  "/>
          <polygon fill="#E8AC25" points="85.167,168 81.833,198.667 82.5,198.333 86.5,163.833  "/>
          <polyline fill="#E8AC25" points="84,153.167 82.5,167.833 83.333,166 84.5,155.333 84,152.5  "/>
        </g>
        <g>
          <path opacity="0.25" fill="#020202" d="M151.547,209.887c0.11,1.506-4.381,3.564-14.761,4.141   c-8.724,0.482-11.14-0.904-10.914-1.551c0.729-2.082,2.825-2.319,7.603-2.748C143.83,208.803,151.438,208.383,151.547,209.887z"/>
          <path opacity="0.5" fill="#020202" d="M141.916,211.833c-0.666,2.667-3.219,2.291-5.979,2.146   c-7.021-0.369-10.063-0.209-9.688-2.125c0.178-0.912,2.479-0.742,7.083-0.742S142.143,210.932,141.916,211.833z"/>
          <polygon fill="#F9CB42" points="134.666,148 126,213.333 137.333,214 145.166,148.5  "/>
          <polyline fill="#EAAE02" points="137.333,214 139,211.333 146.333,150.333 145.166,148.5  "/>
          <polygon fill="#E8AC25" points="134.5,160.333 129.334,198.333 130.5,196.833 134.834,163.333  "/>
          <polygon fill="#E8AC25" points="141.667,155.333 137.667,182.333 139.667,180.5 140.083,177.5 142.5,157  "/>
          <polygon fill="#E8AC25" points="134.334,202.5 132.667,213.167 134,213.167  "/>
        </g>
        <g>
          <path opacity="0.25" fill="#020202" d="M125.334,194.334c0.161,1.261-0.811,2.682-12.52,4.025   c-9.838,1.131-12.602,0.158-12.363-0.403c0.772-1.815,3.133-2.192,8.519-2.948C120.641,193.371,125.173,193.072,125.334,194.334z"/>
          <path opacity="0.5" fill="#020202" d="M113.668,196.954c-0.561,2.241-2.707,1.927-5.027,1.805   c-5.903-0.312-8.461-0.176-8.146-1.786c0.15-0.768,2.086-0.625,5.956-0.625C110.321,196.348,113.857,196.195,113.668,196.954z"/>
          <polygon fill="#FFDF92" points="93.833,138.167 100.5,197.667 109.167,199.167 102.833,137.167  "/>
          <polyline fill="#EAAE02" points="109,199.167 110.5,197.333 104.5,138.5 102.833,137.167  "/>
          <polygon fill="#EAC471" points="97.5,146.167 98.333,157.167 98.5,148.333  "/>
          <polygon fill="#EAC471" points="103.503,163.633 104.77,176.141 105.506,175.87 103.741,159.688 103.525,161.541  "/>
          <polygon fill="#EAC471" points="99.5,167 102.333,197.5 103.833,197.833 99.333,160  "/>
        </g>
        <g>
          <polygon fill="#EEAD09" points="60.583,126.833 178,140.5 182,92.5 62.667,85.833  "/>
          <polygon fill="#9E710E" points="178,140.5 180.667,137.833 185,91.5 66.667,84.167 62.667,85.833 181.667,93.167  "/>
          <polygon fill="#D39B0D" points="180.334,113.5 178.334,138.167 179.667,137.833  "/>
          <polygon fill="#D39B0D" points="181.667,94.167 182,112.167 183.334,93.5  "/>
          <polygon fill="#D39B0D" points="111.334,87.167 168,92.042 169.625,91.542  "/>
          <polygon fill="#D39B0D" points="78.5,109.667 157,114.667 179.5,118.917 88.833,111.667  "/>
          <polygon fill="#D39B0D" points="120.667,125 176.334,130.333 175.834,133.333 104.167,125.333  "/>
          <polygon fill="#D39B0D" points="62.667,91.5 88,94 62.417,92.917  "/>
          <polygon fill="#D39B0D" points="179.202,125.102 151.948,124.367 179.3,126.54  "/>
          <polygon fill="#D39B0D" points="150.622,95 180,96.5 179.486,98.833 142.167,95.333  "/>
        </g>
        <g>
          <path opacity="0.25" d="M173.021,203.592c0.162,1.262-3.541,3.199-12.285,4.162c-7.352,0.811-9.453-0.246-9.293-0.797   c0.521-1.786,2.281-2.085,6.3-2.665C166.451,203.036,172.859,202.332,173.021,203.592z"/>
          <path opacity="0.5" d="M164.668,205.954c-0.561,2.241-2.707,1.927-5.027,1.805c-5.899-0.312-8.461-0.176-8.146-1.786   c0.149-0.768,2.086-0.625,5.956-0.625C161.32,205.348,164.857,205.195,164.668,205.954z"/>
          <polygon fill="#FFDF92" points="145.833,147.167 152.5,206.667 161.167,208.167 154.833,146.167  "/>
          <polygon fill="#EAC471" points="150.167,152.667 151.667,175.833 152.334,173.971 151.334,153.908  "/>
          <polyline fill="#EAAE02" points="154.833,146.167 156.5,147.5 162.5,206.333 161,208.167  "/>
          <polygon fill="#EAC471" points="153,195.333 154,206.5 154.834,206 153.5,193.333  "/>
        </g>
        <g>
          <polygon fill="#EAAE02" points="65.166,153.417 169.666,165.833 172.167,145.167 67,133.5  "/>
          <polygon fill="#D39B0D" points="73.5,140.167 162,147 161.5,149.833 72.833,142.667  "/>
          <polygon fill="#D39B0D" points="113.667,154 169.334,159.333 168.834,162.333 97.167,154.333  "/>
          <polygon fill="#D39B0D" points="172.167,145.167 67,133.5 71.667,132.833 173.834,143.5 171.334,165 169.666,165.833  "/>
          <g>
            <polygon fill="#050102" points="66.875,137.042 171.311,148.691 170,160.167 65.915,148.361   "/>
            <polygon fill="#FAEC31" points="70.579,149.434 65.827,148.909 74.824,138.064 79.575,138.589   "/>
            <polygon fill="#FAEC31" points="82.935,150.794 78.183,150.27 87.179,139.427 91.932,139.952   "/>
            <polygon fill="#FAEC31" points="94.339,152.052 89.587,151.527 98.584,140.686 103.336,141.208   "/>
            <polygon fill="#FAEC31" points="105.745,153.309 100.993,152.786 109.99,141.943 114.742,142.465   "/>
            <polygon fill="#FAEC31" points="117.148,154.566 112.397,154.043 121.395,143.2 126.146,143.723   "/>
            <polygon fill="#FAEC31" points="128.555,155.825 123.803,155.301 132.8,144.458 137.552,144.98   "/>
            <polygon fill="#FAEC31" points="139.959,157.083 135.207,156.557 144.205,145.714 148.958,146.239   "/>
            <polygon fill="#FAEC31" points="151.363,158.339 146.613,157.814 155.609,146.971 160.361,147.497   "/>
            <polygon fill="#FAEC31" points="162.77,159.596 158.018,159.073 167.016,148.229 171.768,148.752   "/>
          </g>
        </g>
        <text transform="matrix(0.9957 0.0931 -0.0931 0.9957 93.4336 105.4668)" font-family="'Tahoma-Bold'" font-size="16.0007">UNDER
        </text>
        <text transform="matrix(0.9957 0.0931 -0.0931 0.9957 70.8691 117.54)" font-family="'Tahoma-Bold'" font-size="12.0005">CONSTRUCTION
        </text>
        <g>
          <polygon fill="#5A5832" points="160,87.389 160,90.896 153.898,90.516 153.823,86.348  "/>
          <polygon fill="#6B6943" points="162.736,87.709 162.706,90.58 160,90.896 160,87.389  "/>
          <path fill="#3F3F3E" d="M154.209,88.952c0,0,3.918,1.012,5.691,0.321c0,0,0.201-1.479-0.28-2.246c0,0-4.749,0.527-5.411,0   C154.209,87.027,153.818,88.411,154.209,88.952z"/>
          <ellipse fill="#828065" cx="158.538" cy="81.888" rx="8.017" ry="6.863"/>
          <circle fill="#D1CFB0" cx="157.475" cy="81.216" r="7.155"/>
          <path fill="none" stroke="#EFECDA" stroke-width="0.5" stroke-miterlimit="10" d="M157.477,75.023   c-3.422,0-6.191,2.773-6.191,6.193s2.771,6.193,6.191,6.193"/>
          <circle fill="#6B6B6B" stroke="#3F2900" stroke-miterlimit="10" cx="157.475" cy="81.216" r="5.591"/>
          <path opacity="0.3" fill="#FFFFFF" d="M162.465,83.922c0,0-1.502,3.487-5.771,2.465c0,0-4.207-0.66-4.81-4.088   C151.884,82.299,156.093,85.245,162.465,83.922z"/>
          <circle fill="#6B5637" cx="157.295" cy="80.615" r="2.164"/>
          <path opacity="0.2" fill="#FFFFFF" d="M158.457,75.605c0,0,4.449,1.483,4.449,5.451c0,0-2.004-2.044-4.85-2.365   c0,0-3.85-0.802-5.41-0.12C152.646,78.571,154.529,75.285,158.457,75.605z"/>
          <circle fill="none" stroke="#494949" stroke-width="0.5" stroke-miterlimit="10" cx="157.475" cy="81.216" r="5.591"/>
        </g>
        <g>
          <polygon fill="#5A5832" points="90,83.389 90,86.896 83.898,86.516 83.823,82.348  "/>
          <polygon fill="#6B6943" points="92.736,83.709 92.706,86.58 90,86.896 90,83.389  "/>
          <path fill="#3F3F3E" d="M84.209,84.952c0,0,3.918,1.012,5.691,0.321c0,0,0.201-1.479-0.28-2.246c0,0-4.749,0.527-5.411,0   C84.209,83.027,83.818,84.411,84.209,84.952z"/>
          <ellipse fill="#828065" cx="88.538" cy="77.888" rx="8.017" ry="6.863"/>
          <circle fill="#D1CFB0" cx="87.475" cy="77.216" r="7.155"/>
          <path fill="none" stroke="#EFECDA" stroke-width="0.5" stroke-miterlimit="10" d="M87.477,71.023c-3.422,0-6.191,2.773-6.191,6.193   s2.771,6.193,6.191,6.193"/>
          <circle fill="#6B6B6B" stroke="#3F2900" stroke-miterlimit="10" cx="87.475" cy="77.216" r="5.591"/>
          <path opacity="0.3" fill="#FFFFFF" d="M92.465,79.922c0,0-1.502,3.487-5.771,2.465c0,0-4.207-0.66-4.81-4.088   C81.884,78.299,86.093,81.245,92.465,79.922z"/>
          <circle fill="#6B5637" cx="87.295" cy="76.615" r="2.164"/>
          <path opacity="0.2" fill="#FFFFFF" d="M88.457,71.605c0,0,4.449,1.483,4.449,5.451c0,0-2.004-2.044-4.85-2.365   c0,0-3.85-0.802-5.41-0.12C82.646,74.571,84.529,71.285,88.457,71.605z"/>
          <circle fill="none" stroke="#494949" stroke-width="0.5" stroke-miterlimit="10" cx="87.475" cy="77.216" r="5.591"/>
        </g>
        <g id="lighting1" opacity="0.610812633330606">	
          <radialGradient id="SVGID_1_" cx="344.041" cy="33.875" r="32.125" gradientTransform="matrix(1 0 0 -1 -186 115)" gradientUnits="userSpaceOnUse">
            <stop offset="0.1515" style="stop-color:#FFB92E"/>
            <stop offset="1" style="stop-color:#FFAC2E;stop-opacity:0"/>
          </radialGradient>
          <circle fill="url(#SVGID_1_)" cx="158.041" cy="81.125" r="32.125"/>
          <circle fill="#FAB534" cx="158.1" cy="81.382" r="5.591"/>
          <path opacity="0.5" fill="#FFFFFF" enable-background="new    " d="M163.09,84.088c0,0-1.502,3.487-5.771,2.465   c0,0-4.207-0.66-4.81-4.088C152.509,82.465,156.718,85.411,163.09,84.088z"/>
          <circle fill="#FCCD49" cx="157.92" cy="80.781" r="1.414"/>
          <path fill="#F9CC9B" d="M159.082,75.771c0,0,4.449,1.483,4.449,5.451c0,0-2.004-2.044-4.85-2.365c0,0-3.85-0.802-5.41-0.12   C153.271,78.737,155.154,75.451,159.082,75.771z"/>
          <path fill="none" stroke="#FFAD3F" stroke-width="0.5" stroke-miterlimit="10" d="M157.977,75.189   c-3.422,0-6.193,2.773-6.193,6.193s2.771,6.193,6.193,6.193"/>
          <circle fill="none" stroke="#FFE79F" stroke-width="0.5" stroke-miterlimit="10" cx="157.975" cy="81.382" r="5.591"/>
        </g>
        <g id="lighting2" opacity="0.610812633330606">	
          <radialGradient id="SVGID_2_" cx="274.041" cy="37.875" r="32.125" gradientTransform="matrix(1 0 0 -1 -186 115)" gradientUnits="userSpaceOnUse">
            <stop offset="0.1515" style="stop-color:#FFB92E"/>
            <stop offset="1" style="stop-color:#FFAC2E;stop-opacity:0"/>
          </radialGradient>
          <circle fill="url(#SVGID_2_)" cx="88.041" cy="77.125" r="32.125"/>
          <circle fill="#FAB534" cx="88.1" cy="77.382" r="5.591"/>
          <path opacity="0.5" fill="#FFFFFF" enable-background="new    " d="M93.09,80.088c0,0-1.502,3.487-5.771,2.465   c0,0-4.207-0.66-4.81-4.088C82.509,78.465,86.718,81.411,93.09,80.088z"/>
          <circle fill="#FCCD49" cx="87.92" cy="76.781" r="1.414"/>
          <path fill="#F9CC9B" d="M89.082,71.771c0,0,4.449,1.483,4.449,5.451c0,0-2.004-2.044-4.85-2.365c0,0-3.849-0.802-5.41-0.12   C83.271,74.737,85.154,71.451,89.082,71.771z"/>
          <path fill="none" stroke="#FFAD3F" stroke-width="0.5" stroke-miterlimit="10" d="M87.976,71.189c-3.422,0-6.193,2.773-6.193,6.193   s2.771,6.193,6.193,6.193"/>
          <circle fill="none" stroke="#FFE79F" stroke-width="0.5" stroke-miterlimit="10" cx="87.974" cy="77.382" r="5.591"/>
        </g>
        <script type="text/javascript">
          <![CDATA[
            function startAnimation(){
              null==Interval&&(Interval=setInterval(animate,10))}
            function stopAnimation(){
            null!=Interval&&(clearInterval(Interval),Interval=null)}
            function animate(){
            aniPoints+=1,aniPoints>10&&55>aniPoints&&(endAnimation=!1,fast_+=(2-fast_)/10,rot1_1+=(rot1_2-rot1_1)/fast_,rot2_1+=(rot2_2-rot2_1)/fast_,leaver_1.setAttribute("opacity",rot1_1),leaver_2.setAttribute("opacity",rot2_1)),aniPoints>75&&125>aniPoints&&(endAnimation=!1,fast_2+=(2-fast_2)/10,rot1_1+=(rot1_3-rot1_1)/fast_2,rot2_1+=(rot2_3-rot2_1)/fast_2,leaver_1.setAttribute("opacity",rot1_1),leaver_2.setAttribute("opacity",rot2_1)),aniPoints>175&&!endAnimation&&(endAnimation=!0,aniPoints=0,fast_=50,fast_2=50,fast_3=50,fast_4=50,fast_5=50,fast_6=50,fast_7=50)}
            var endInterval=0,rot1_1=0,rot1_2=1,rot1_3=0,rot1_4=0,rot1_5=20,rot2_1=0,rot2_2=1,rot2_3=0,rot2_4=20,rot2_5=50,rot3_1=0,rot3_2=50,rot3_3=-20,rot3_4=120,rot3_5=0,fast_=50,fast_2=50,fast_3=50,fast_4=50,fast_5=50,fast_6=50,fast_7=50,aniPoints=0,nextStep=!1,endAnimation=!1,leaver_1=document.getElementById("lighting1"),leaver_2=document.getElementById("lighting2"),pari=-1,pariSpd=0,Interval=null;
            leaver_1.setAttribute("opacity",0),leaver_2.setAttribute("opacity",0),startAnimation();
          ]]>
        </script>
      </svg>        
    </div>
  </body>
</html>
<?php 
}
/* EOF */
?>