<?php
/*
Plugin Name: Easy Under Construction
Plugin URI: https://wordpress.org/plugins/easy-under-construction
Description: Easy under construction is a one click under construction mode enabler, which allows the WordPress site administrator to close the website for maintenance.
Version: 4.0
Requires at least: 3.1
Tested up to: 5.5.3
Requires PHP: 5.2
Author: Abbas Khalil
Author URI: https://profiles.wordpress.org/linekal/
*/
?>
<?php
if ( ! function_exists( 'euc_fs' ) ) {
    // Create a helper function for easy SDK access.
    function euc_fs() {
        global $euc_fs;

        if ( ! isset( $euc_fs ) ) {
            // Include Freemius SDK.
            require_once dirname(__FILE__) . '/freemius/start.php';

            $euc_fs = fs_dynamic_init( array(
                'id'                  => '7218',
                'slug'                => 'easy-under-construction',
                'type'                => 'plugin',
                'public_key'          => 'pk_653dd0971483ed3a0221cad4ff3b1',
                'is_premium'          => false,
                'has_addons'          => false,
                'has_paid_plans'      => false,
                'menu'                => array(
                    'slug'           => 'easy-under-construction',
                    'account'        => false,
                    'contact'        => false,
                    'support'        => false,
                ),
            ) );
        }

        return $euc_fs;
    }

    // Init Freemius.
    euc_fs();
    // Signal that SDK was initiated.
    do_action( 'euc_fs_loaded' );
}

if (!defined('EASYUNDERCONSTRUCTION_PLUGIN_DIR'))
{
    define('EASYUNDERCONSTRUCTION_PLUGIN_DIR', dirname(__FILE__));
}
class easyunderConstruction
{
    var $installedFolder = "";
    var $mainOptionsPage = "easy-under-construction";
    function __construct()
    {
        $this->installedFolder = basename(dirname(__FILE__));
    }
    function easyunderConstruction()
    {
        $this->__construct();
    }
    function getMainOptionsPage()
    {
        return $this->mainOptionsPage;
    }
    function easyunderConstructionAdminInit()
    {
        /* Register script. */
        wp_enqueue_script('easy-under-construction-admin', plugin_dir_url(__FILE__) . 'scripts/easyuc-scripts.js', array(
            'jquery'
        ));
        wp_enqueue_style('easy-under-construction-admin-style', plugin_dir_url(__FILE__) . 'styles/easyuc-style.css', array() , '1.1');
    }
    function easyuc_changeMessage()
    {
        require_once ('easyucOptions.php');
    }
    function easyuc_adminMenu()
    {
        /* Register our plugin page */
        $page = add_options_page('Easy Under Construction Settings', 'Easy Under Construction', 'activate_plugins', $this->mainOptionsPage, array(
            $this,
            'easyuc_changeMessage'
        ));
        /* Using registered $page handle to hook script load */
        add_action('admin_print_scripts-' . $page, array(
            $this,
            'easyunderConstructionEnqueueScripts'
        ));
    }
    function easyuc_overrideWP()
    {
        if ($this->pluginIsActive())
        {
            if (!is_user_logged_in())
            {
                if (!in_array(inet_ntop(inet_pton($_SERVER['REMOTE_ADDR'])) , $array))
                {
                    //send a 503 if the setting requires it
                    if (get_option('easyunderConstructionHTTPStatus') == 503)
                    {
                        header('HTTP/1.1 503 Service Unavailable');
                    }
                    //send a 503 if the setting requires it
                    if (get_option('easyunderConstructionHTTPStatus') == 301)
                    {
                        header("HTTP/1.1 301 Moved Permanently");
                        header("Location: " . get_option('easyunderConstructionRedirectURL'));
                    }
                    if ($this->displayStatusCodeIs(0)) //they want the default!
                    
                    {
                        require_once ('defaultMessage.php');
                        displayDefaultComingSoonPage();
                        die();
                    }
                    //Start custom templates here
                    if ($this->displayStatusCodeIs(4)) //tempate one
                    
                    {
                        require_once ('templates/one.php');
                        displayDefaultComingSoonPage();
                        die();
                    }
                    if ($this->displayStatusCodeIs(5)) //tempalte two
                    
                    {
                        require_once ('templates/two.php');
                        displayDefaultComingSoonPage();
                        die();
                    }
                    if ($this->displayStatusCodeIs(6)) //tempalte two
                    
                    {
                        require_once ('templates/three.php');
                        displayDefaultComingSoonPage();
                        die();
                    }
                    //End custom templates here
                    if ($this->displayStatusCodeIs(1)) //they want the default with custom text!
                    
                    {
                        require_once ('defaultMessage.php');
                        displayComingSoonPage($this->getCustomPageTitle() , $this->getCustomHeaderText() , $this->getCustomBodyText());
                        die();
                    }
                    if ($this->displayStatusCodeIs(2)) //they want custom HTML!
                    
                    {
                        echo html_entity_decode($this->getCustomHTML() , ENT_QUOTES);
                        die();
                    }
                    if ($this->displayStatusCodeIs(3))
                    {
                        require_once (get_template_directory() . '/easy-under-construction.php');
                        die();
                    }
                }
            }
        }
    }
    function easyuc_admin_override_WP()
    {
        if (!$this->pluginIsActive())
        {
            return;
        }
        if (get_option('easyunderConstructionRequiredRole') && is_user_logged_in())
        {
            global $wp_roles;
            $all_roles = $wp_roles->roles;
            $editable_roles = apply_filters('editable_roles', $all_roles);
            $required_role = $editable_roles[get_option('easyunderConstructionRequiredRole') ];
            $new_privs = array();
            foreach ($required_role['capabilities'] as $key => $value)
            {
                if ($value == true)
                {
                    $new_privs[] = $key;
                }
            }
            if (!current_user_can($new_privs[0]))
            {
                wp_logout();
                wp_redirect(get_bloginfo('url'));
            }
        }
    }
    function getCustomHTML()
    {
        return stripslashes(get_option('easyunderConstructionHTML'));
    }
    function getbgcolor()
    {
        return stripslashes(get_option('easyunderConstructionbgcolor'));
    }
    function getbgcolor_two()
    {
        return stripslashes(get_option('easyunderConstructionbgcolor_two'));
    }
    function getbgcolor_three()
    {
        return stripslashes(get_option('easyunderConstructionbgcolor_three'));
    }
    function easyuc_activate()
    {
        if (get_option('easyunderConstructionArchive'))
        {
            //get all the options back from the archive
            $options = get_option('easyunderConstructionArchive');
            //put them back where they belong
            update_option('easyunderConstructionHTML', $options['easyunderConstructionHTML']);
            update_option('easyunderConstructionActivationStatus', $options['easyunderConstructionActivationStatus']);
            update_option('easyunderConstructionCustomText', $options['easyunderConstructionCustomText']);
            update_option('easyunderConstructionDisplayOption', $options['easyunderConstructionDisplayOption']);
            update_option('easyunderConstructionHTTPStatus', $options['easyunderConstructionHTTPStatus']);
            delete_option('easyunderConstructionArchive');
        }
    }
    function easyuc_deactivate()
    {
        //get all the options. store them in an array
        $options = array();
        $options['easyunderConstructionHTML'] = get_option('easyunderConstructionHTML');
        $options['easyunderConstructionActivationStatus'] = get_option('easyunderConstructionActivationStatus');
        $options['easyunderConstructionCustomText'] = get_option('easyunderConstructionCustomText');
        $options['easyunderConstructionDisplayOption'] = get_option('easyunderConstructionDisplayOption');
        $options['easyunderConstructionHTTPStatus'] = get_option('easyunderConstructionHTTPStatus');
        //store the options all in one record, in case we ever reactivate the plugin
        update_option('easyunderConstructionArchive', $options);
        //delete the separate ones
        delete_option('easyunderConstructionHTML');
        delete_option('easyunderConstructionActivationStatus');
        delete_option('easyunderConstructionCustomText');
        delete_option('easyunderConstructionDisplayOption');
        delete_option('easyunderConstructionHTTPStatus');
    }
    function pluginIsActive()
    {
        if (!get_option('easyunderConstructionActivationStatus')) //if it's not set yet
        
        {
            return false;
        }
        if (get_option('easyunderConstructionActivationStatus') == 1)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    function httpStatusCodeIs($status)
    {
        if (!get_option('easyunderConstructionHTTPStatus')) //if it's not set yet
        
        {
            update_option('easyunderConstructionHTTPStatus', 200); //set it
            
        }
        if (get_option('easyunderConstructionHTTPStatus') == $status)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    function displayStatusCodeIs($status)
    {
        if (!get_option('easyunderConstructionDisplayOption')) //if it's not set yet
        
        {
            update_option('easyunderConstructionDisplayOption', 0); //set it
            
        }
        if (get_option('easyunderConstructionDisplayOption') == $status)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    function getCustomPageTitle()
    {
        if (get_option('easyunderConstructionCustomText') != false)
        {
            $fields = get_option('easyunderConstructionCustomText');
            return stripslashes($fields['pageTitle']);
        }
        else
        {
            return '';
        }
    }
    function getCustomHeaderText()
    {
        if (get_option('easyunderConstructionCustomText') != false)
        {
            $fields = get_option('easyunderConstructionCustomText');
            return stripslashes($fields['headerText']);
        }
        else
        {
            return '';
        }
    }
    function getCustomBodyText()
    {
        if (get_option('easyunderConstructionCustomText') != false)
        {
            $fields = get_option('easyunderConstructionCustomText');
            return stripslashes($fields['bodyText']);
        }
        else
        {
            return '';
        }
    }
    function plugin_deactivate()
    {
        delete_option('easyunderconstruction_global_notification');
    }
    function admin_menu_link()
    {
        add_menu_page('Easy Under Construction', 'Easy Under Construction', 'manage_options', 'easy-under-construction', array(&$this,
            'easyuc_changeMessage'
        ) , 'dashicons-admin-generic');
        add_submenu_page('easy-under-construction', 'Pro Services', 'Pro Services', 'manage_options', 'easy-under-construction-plugin-pro-services', array(
            $this,
            'easyuc_pro_services'
        ));
    }
    function easyuc_filter_plugin_actions($links, $file)
    {
        $settings_link = '<a href="admin.php?page=easyunderConstruction">' . __('Settings') . '</a>';
        array_unshift($links, $settings_link);
        return $links;
    }
    function easyuc_pro_services()
    {
        include (EASYUNDERCONSTRUCTION_PLUGIN_DIR . '/services.php');
    }    
    function easyuc_handle_external_redirects()
    {
        if (empty($_GET['page']))
        {
            return;
        }
    }
}
$easyunderConstructionPlugin = new easyunderConstruction();
add_action('template_redirect', array(
    $easyunderConstructionPlugin,
    'easyuc_overrideWP'
));
add_action('admin_init', array(
    $easyunderConstructionPlugin,
    'easyuc_admin_override_WP'
));
add_action('wp_login', array(
    $easyunderConstructionPlugin,
    'easyuc_admin_override_WP'
));
add_action('plugins_loaded', 'easyunderConstructionInitTranslation');
add_action('admin_init', array(
    $easyunderConstructionPlugin,
    'easyunderConstructionAdminInit'
));
register_activation_hook(__FILE__, array(
    $easyunderConstructionPlugin,
    'easyuc_activate'
));
register_deactivation_hook(__FILE__, array(
    $easyunderConstructionPlugin,
    'easyuc_deactivate'
));
register_uninstall_hook(__FILE__, 'easyunderConstructionPlugin_delete');
add_action("admin_menu", array(
    $easyunderConstructionPlugin,
    'admin_menu_link'
));
function easyunderConstructionPlugin_delete()
{
    delete_option('easyunderConstructionArchive');
}
function easyunderConstructionPluginLinks($links, $file)
{
    global $easyunderConstructionPlugin;
    if ($file == basename(dirname(__FILE__)) . '/' . basename(__FILE__) && function_exists("admin_url"))
    {
        //add settings page
        $manage_link = '<a href="' . admin_url('?page=' . $easyunderConstructionPlugin->getMainOptionsPage()) . '">' . __('Settings') . '</a>';
        array_unshift($links, $manage_link);
    }
    return $links;
}
add_filter('plugin_action_links', 'easyunderConstructionPluginLinks', 10, 2);
//ajax
add_option('easyunderconstruction_global_notification', 1);
//add_action( 'admin_notices', array($easyunderConstructionPlugin, 'global_notice') );
register_deactivation_hook(__FILE__, array(
    $easyunderConstructionPlugin,
    'plugin_deactivate'
));