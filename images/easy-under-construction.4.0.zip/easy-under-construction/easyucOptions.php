<?php
if($_SERVER['REQUEST_METHOD'] == "POST"){
if(!wp_verify_nonce($_POST['save_options_field'], 'save_options') || ! current_user_can('publish_pages')){
die("Sorry, but this request is invalid");
}
}
if (isset($_GET['turnOnUnderConstructionMode']))
{
update_option('easyunderConstructionActivationStatus', 1);
}
if (isset($_GET['turnOffUnderConstructionMode']))
{
update_option('easyunderConstructionActivationStatus', 0);
}
// ======================================
// 		process display options
// ======================================
if (isset($_POST['display_options']))
{
if ($_POST['display_options'] == 0) //they want to just use the default
{
update_option('easyunderConstructionDisplayOption', 0);
}
if ($_POST['display_options'] == 1) //they want to use the default with custom text
{
$values = array('pageTitle'=>'', 'headerText'=>'', 'bodyText'=>'');
if (isset($_POST['pageTitle']))
{
$values['pageTitle'] = sanitize_text_field($_POST['pageTitle']);
}
if (isset($_POST['headerText']))
{
$values['headerText'] = sanitize_text_field($_POST['headerText']);
}
if (isset($_POST['bodyText']))
{
$values['bodyText'] = sanitize_textarea_field($_POST['bodyText']);
}
update_option('easyunderConstructionCustomText', $values);
update_option('easyunderConstructionDisplayOption', 1);
}
if ($_POST['display_options'] == 2) //they want to use their own HTML
{
if (isset($_POST['ucHTML']))
{
update_option('easyunderConstructionHTML', wp_kses_post($_POST['ucHTML']));
update_option('easyunderConstructionDisplayOption', 2);
}
}
if ($_POST['display_options'] == 3){ //they want to use the Easy Under Construction page in their theme
update_option('easyunderConstructionDisplayOption', 3);
}
if ($_POST['display_options'] == 4){ // Template one
if (isset($_POST['bgcolor']))
{
update_option('easyunderConstructionbgcolor', sanitize_hex_color($_POST['bgcolor']));
update_option('easyunderConstructionDisplayOption', 4);
}	
}	
if ($_POST['display_options'] == 5){ // Template two
if (isset($_POST['bgcolor_two']))
{
update_option('easyunderConstructionbgcolor_two', sanitize_hex_color($_POST['bgcolor_two']));
update_option('easyunderConstructionDisplayOption', 5);
}	
}	
if ($_POST['display_options'] == 6){ // Template two
if (isset($_POST['bgcolor_three']))
{
update_option('easyunderConstructionbgcolor_three', sanitize_hex_color($_POST['bgcolor_three']));
update_option('easyunderConstructionDisplayOption', 6);
}	
}	
}
// ======================================
// 		process http status codes
// ======================================
if (isset($_POST['activate']))
{
if ($_POST['activate'] == 0)
{
update_option('easyunderConstructionActivationStatus', 0);
}
if ($_POST['activate'] == 1)
{
update_option('easyunderConstructionActivationStatus', 1);
}
}
// ======================================
// 		process on/off status
// ======================================
if (isset($_POST['http_status']))
{
if ($_POST['http_status'] == 200)
{
update_option('easyunderConstructionHTTPStatus', 200);
}
if ($_POST['http_status'] == 301)
{
update_option('easyunderConstructionHTTPStatus', 301);
update_option('easyunderConstructionRedirectURL', esc_url($_POST['url']));
}
if ($_POST['http_status'] == 503)
{
update_option('easyunderConstructionHTTPStatus', 503);
}
}
// ======================================
// 		User Roles
// ======================================
if(isset($_POST['required_role'])){
update_option('easyunderConstructionRequiredRole', sanitize_text_field($_POST['required_role']));
}
$current_theme_has_easyuc_page = file_exists(get_template_directory() . '/easy-under-construction.php');
add_thickbox();
if (array_key_exists('easyunderconstruction_global_notification', $_GET) && $_GET['easyunderconstruction_global_notification'] == 0) {
update_option('easyunderconstruction_global_notification', 0);
}
?>
<noscript>
  <div class='updated' id='javascriptWarn'>
    <p>
      <?php _e('JavaScript appears to be disabled in your browser. For this plugin to work correctly, please enable JavaScript or switch to a more modern browser.', 'easyunderconstruction');?>
    </p>
  </div>
</noscript>
<style type="text/css">
  #easyunderconstruction_global_notification a.button:active {
    vertical-align:baseline;
  }
</style> 
<div class="wrap">
  <div class="easy-under-construction-content-left">
    <div id="icon-options-general" class="icon32">
      <br />
    </div>
    <form method="post"
          action="<?php echo $GLOBALS['PHP_SELF'] . '?page=' . $this->mainOptionsPage; ?>"
          id="ucoptions">
      <table>
        <tr>
          <td>
            <h3>
              <?php _e('Activate Under Construction Mode', 'easyunderconstruction');?>
            </h3>
          </td>
        </tr>
        <tr>
          <td>
            <fieldset>
              <div class="switch-field">
                <input type="radio" id="radio-one" name="activate" value="1"
                       <?php if ($this->pluginIsActive()) { echo ' checked="checked"'; } ?>>
                <label for="radio-one">Yes
                </label>
                <input type="radio" id="radio-two" name="activate" value="0"
                       <?php if (!$this->pluginIsActive()) { echo ' checked="checked"'; } ?>>
                <label for="radio-two">No
                </label>
              </div>
            </fieldset>
          </td>
        </tr>
        <tr>
          <td>
            <h3>
              <?php _e('Display Options', 'easyunderconstruction');?>
            </h3>
          </td>
        </tr>
        <tr>
          <td>
            <fieldset>				
              <div class="select_template"> 
                <input type="radio" name="display_options" value="4" id="displayOption4"
                       <?php if ($this->displayStatusCodeIs(4)) { echo ' checked="checked"'; } ?>>&nbsp;
                <?php _e('Template one', 'easyunderconstruction');?>
                <img src="<?php echo plugin_dir_url(__FILE__) . "templates/images/thumb_one.png"; ?>">	
				<label title="<?php _e('Select Background color Color', 'easyunderconstruction');?>"> 
                  Background 
                  <input name="bgcolor" type="color" id="bgcolor" value="<?php echo $this->getbgcolor(); ?>">
                </label> 
                <br />			
              </div> 	
              <div class="select_template"> 
                <input type="radio" name="display_options" value="5" id="displayOption5"
                       <?php if ($this->displayStatusCodeIs(5)) { echo ' checked="checked"'; } ?>>&nbsp;
                <?php _e('Template two', 'easyunderconstruction');?>
                <img src="<?php echo plugin_dir_url(__FILE__) . "templates/images/thumb_two.png"; ?>">	
                <label title="<?php _e('Select Background color Color', 'easyunderconstruction');?>"> 
                  Background 
                  <input name="bgcolor_two" type="color" id="bgcolor_two" value="<?php echo $this->getbgcolor_two(); ?>">
                </label> 
                <br />			
              </div> 				
              <div class="select_template"> 
                <input type="radio" name="display_options" value="6" id="displayOption6"
                       <?php if ($this->displayStatusCodeIs(6)) { echo ' checked="checked"'; } ?>>&nbsp;
                <?php _e('Template three', 'easyunderconstruction');?>
                <img src="<?php echo plugin_dir_url(__FILE__) . "templates/images/thumb_three.png"; ?>">	
                <label title="<?php _e('Select Background color Color', 'easyunderconstruction');?>"> 
                  Background 
                  <input name="bgcolor_three" type="color" id="bgcolor_three" value="<?php echo $this->getbgcolor_three(); ?>">
                </label> 
                <br />			
              </div> 					
            </fieldset>
          </td>
        </tr>				
        <tr>
          <td>
            <fieldset>
              <legend class="screen-reader-text">
                <span>
                  <?php _e('Display Options', 'easyunderconstruction');?> 
                </span>
              </legend>
              <label title="<?php _e('Display default Under Construction page', 'easyunderconstruction');?>">
                <input type="radio" name="display_options" value="0" id="displayOption0"
                       <?php if ($this->displayStatusCodeIs(0)) { echo ' checked="checked"'; } ?>>&nbsp;
                <?php _e('Default Under Construction page', 'easyunderconstruction');?>
              </label> 
              <br />
              <label title="<?php _e('Display the Under Construction page that is part of the active theme', 'easyunderconstruction');?>">
                <input 
                       <?php if(!$current_theme_has_easyuc_page): ?>disabled="disabled" 
                <?php endif; ?> type="radio" name="display_options" value="3" id="displayOption3"
                <?php if ($this->displayStatusCodeIs(3)) { echo ' checked="checked"'; } ?>>&nbsp;
                <?php _e('Display the Under Construction page that is part of the active theme', 'easyunderconstruction');?>
                <?php if(!$current_theme_has_easyuc_page): ?>
                <br /> 
                <em style="margin-left: 24px;">
                  <?php _e('Only available for themes with an easy-under-construction.php file', 'easyunderconstruction');?>
                </em>
                <?php endif; ?>
              </label> 
              <br /> 
              <label title="<?php _e('Display the default Under Construction page, but use custom text', 'easyunderconstruction');?>"> 
                <input type="radio" name="display_options" value="1" id="displayOption1"
                       <?php if ($this->displayStatusCodeIs(1)) { echo ' checked="checked"'; } ?>>&nbsp;
                <?php _e('Display the default Under Construction page, but use custom text', 'easyunderconstruction');?>
              </label> 
              <br /> 
              <label title="<?php _e('Display a custom page using your own HTML', 'easyunderconstruction');?>"> 
                <input type="radio" name="display_options" value="2" id="displayOption2"
                       <?php if ($this->displayStatusCodeIs(2)) { echo ' checked="checked"'; } ?>>&nbsp;
                <?php _e('Display a custom page using your own HTML', 'easyunderconstruction');?>
              </label> 
              <br /> 					
            </fieldset>
          </td>
        </tr>
      </table>
      <div id="customHTML"
           <?php if (!$this->displayStatusCodeIs(2)) { echo ' style="display: none;"'; } ?>>
      <h3>
        <?php _e('Easy Under Construction Page HTML', 'easyunderconstruction');?>
      </h3>
      <p>
        <?php _e('Put in this area the HTML you want to show up as your under construction Page. (Only wordpress allowed html tags).', 'easyunderconstruction');?>
      </p>
      <?php echo '<textarea name="ucHTML" rows="15" cols="75">'.$this->getCustomHTML().'</textarea>'; ?>
      </div>
    <div id="customText"
         <?php if (!$this->displayStatusCodeIs(1)) { echo ' style="display: none;"'; } ?>>
    <h3>
      <?php _e('Display Custom Text', 'easyunderconstruction');?>
    </h3>
    <p>
      <?php _e('The text here will replace the text on the default page', 'easyunderconstruction');?>
    </p>
    <table>
      <tr valign="top">
        <th scope="row">
          <label for="pageTitle"> 
            <?php _e('Page Title', 'easyunderconstruction');?> 
          </label>
        </th>
        <td>
          <input name="pageTitle" type="text" id="pageTitle" value="<?php echo $this->getCustomPageTitle(); ?>" class="regular-text" size="50">
        </td>
      </tr>
      <tr valign="top">
        <th scope="row">
          <label for="headerText"> 
            <?php _e('Header Text', 'easyunderconstruction');?> 
          </label>
        </th>
        <td>
          <input name="headerText" type="text" id="headerText" value="<?php echo $this->getCustomHeaderText(); ?>" class="regular-text" size="50">
        </td>
      </tr>
      <tr valign="top">
        <th scope="row">
          <label for="bodyText"> 
            <?php _e('Body Text', 'easyunderconstruction');?> 
          </label>
        </th>
        <td>
          <?php echo '<textarea rows="2" cols="44" name="bodyText" id="bodyText" class="regular-text">'.trim($this->getCustomBodyText()).'</textarea>'; ?>
        </td>
      </tr>
    </table>
  </div>
  <table>
    <tr>
      <td>
        <h3>
          <?php _e('HTTP Status Code', 'easyunderconstruction');?>
        </h3>
        <p>
          <?php _e("You can choose to send the standard HTTP status code with the Under Construction page, or send a 503 \"Service Unavailable\" status code. This will tell Google that this page isn't ready yet, and cause your site not to be listed until this plugin is disabled.", 'easyunderconstruction');?>
        </p>
      </td>
    </tr>
    <tr>
      <td>
        <fieldset>
          <legend class="screen-reader-text">
            <span>
              <?php _e('HTTP Status Code', 'easyunderconstruction');?>
            </span>
          </legend>
          <label title="HTTP200">
            <input type="radio" name="http_status" value="200" id="200_status"
                   <?php if ($this->httpStatusCodeIs(200)) { echo ' checked="checked"'; } ?>>&nbsp;
            <?php _e('HTTP 200 - ok', 'easyunderconstruction');?> 
          </label> 
          <br />
          <label title="HTTP301"> 
            <input type="radio" name="http_status" value="301" id="301_status"
                   <?php if ($this->httpStatusCodeIs(301)) { echo ' checked="checked"'; } ?>>&nbsp;
            <?php _e('HTTP 301 - Redirect', 'easyunderconstruction');?> 
          </label> 
          <br />
          <label title="HTTP503">
            <input type="radio" name="http_status" value="503" id="503_status"
                   <?php if ($this->httpStatusCodeIs(503)) { echo ' checked="checked"'; } ?>>&nbsp;
            <?php _e('HTTP 503 - Service Unavailable', 'easyunderconstruction');?>
          </label>
        </fieldset>
        <div id="redirect_panel" 
             <?php echo !$this->httpStatusCodeIs(301) ? 'class="hidden"' : '';?>>
        <br />
        <label for="url">
          <?php _e('Redirect Location:', 'easyunderconstruction');?>
        </label>
        <input type="text" name="url" id="url" value="<?php echo get_option('easyunderConstructionRedirectURL');?>" />
    </div>
    </td>
  </tr>
<tr>
  <td>
    <h3>
      <?php _e('Restrict By Role', 'easyunderconstruction');?>
    </h3>
  </td>
</tr>
<tr>
  <td>
    <?php _e('Only users at or above this level will be able to log in:', 'easyunderconstruction');?> 
    <select id="required_role" name="required_role">
      <option value="0">
        <?php _e('All Users', 'easyunderconstruction');?>
      </option>
      <?php
$selected = get_option('easyunderConstructionRequiredRole');
$editable_roles = get_editable_roles();
//to get rid of Notices "Undefined var"...
$p = $r = '';
foreach ( $editable_roles as $role => $details ) {
$name = translate_user_role($details['name'] );
if ( $selected == $role ) // preselect specified role
$p = "\n\t<option selected='selected' value='" . esc_attr($role) . "'>$name</option>";
else
$r .= "\n\t<option value='" . esc_attr($role) . "'>$name</option>";
}
echo $p . $r;
?>
    </select>
  </td>
</tr>
</table>
<p class="submit">
  <?php wp_nonce_field('save_options','save_options_field'); ?>
  <input type="submit" name="Submit" class="button-primary" value="<?php _e('Save Changes', 'easyunderconstruction'); ?>" id="submitChangesToUnderConstructionPlugin" />
</p>
</form>
</div>
<div class="easy-under-construction-content-right">
  <div class="easy-under-construction-content-container-right">
    <div class="easy-under-construction-promo-box entry-content">
      <p class="easy-under-construction-promo-box-header">Need Help in Development of your Dream website?
      </p>
      <div class="description_of_service">Please feel free to contact me any time whenever you need web development & designing or customization Service. I am always here for your help 24/7.
        <br>	
        <div align="center">
          <br>		
          <strong>Email me directly at: 
            <a href="mailto:abbasahmed50@gmail.com">abbasahmed50@gmail.com
            </a>
          </strong>
          <br>	
          OR
          <br>		
          <strong>
            <a href="<?php echo admin_url('admin.php?page=easy-under-construction-plugin-pro-services'); ?>">Click here
            </a> To fill out the form	on Services page.
          </strong>				
        </div>	
      </div>
      <div class="aboutme_box">
        <img class="profile_pic" src="<?php echo plugin_dir_url(__FILE__) . "templates/images/profile-min.png"; ?>">	  
        ✨
        <strong>A Little About Me:
        </strong> My name is Abbas, I am a wordpress pro developer, I have developed my own plugins for wordpress plugins repository and premium wordpress themes for sale. You can gauge my coding quality from it. I am serving Wordpress community since 2014. With +8 years experience i am here to do something very special for you, my goal here is very simple "100% customer satisfaction". Most of my customers are permanently working with me. I want you to be one of them. My request is to work with me just once. Coming back again and again will be your choice :)
      </div>
      <ul class="bullets">
        <li>
          <strong>Overall Rating: 5.0
          </strong> 
          <span class="dashicons dashicons-star-filled">
          </span>
          <span class="dashicons dashicons-star-filled">
          </span>
          <span class="dashicons dashicons-star-filled">
          </span>
          <span class="dashicons dashicons-star-filled">
          </span>
          <span class="dashicons dashicons-star-filled">
          </span> (783 reviews)		
        </li>
        <li>
          <strong>Number of clients:
          </strong> 500+	
        </li>	
        <li>
          <strong>Completed websites:
          </strong> 400+	
        </li>	
        <li>
          <strong>For portfolio: 
          </strong>
          <a href="<?php echo admin_url('admin.php?page=easy-under-construction-plugin-pro-services'); ?>">Click here
          </a> To fill out the form and i will send you the list as soon as possible.
        </li>	
      </ul>				
    </div>
  </div>
</div>
</div>