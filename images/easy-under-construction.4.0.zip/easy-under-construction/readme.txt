=== Under Construction ===
Plugin Name: Under Construction
Contributors: linekal
Tags: under construction, under construction page, maintenance, coming soon, coming soon page, 
Requires at least: 3.1
Tested up to: 5.9
Requires PHP: 5.2
Stable tag: 4.0
Version: 4.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Under construction is a one click under construction mode enabler, which allows the WordPress site administrator to close the website for maintenance. It is a light weight plugin and highly customizable. Under construction have multiple nicely designed built-in under construction page templates that takes less than a minute to install & configure.

Under construction plugin is **"COMPLETELY FREE AND ALWAYS WILL BE"** for anyone who wants to display an under construction / maintenance page while they are doing work on their site backend.

* Install Under Construction plugin
* Click on "Easy Under Construction" admin menu located in the main WP admin menu
* Select the template which you want from templates menu and click on construction mode â€“ on
* That's it.

<h3>Features</h3>
<ul>
<li>One click under construction mode â€“ on / off</li>
<li>Customize title, headline, body text</li>
<li>Customize background</li>
<li>Unlimited colour Scheme</li>
<li>SEO configuration</li>
<li>503 error on/off</li>
<li>Built-in maintenance templates</li>
<li>Access/Restriction</li>
<li>Responsive Design</li>
<li>Light weight</li>
<li>Custom HTML Page Support</li>
<li>Clean Retina</li>
<li>Flexible and user-friendly setup</li> 
<li>Cross Browser Support</li>
</ul>

<h3>Support</h3>
If you face any problem using Under Construction, please feel free to contact me directly from the plugin options page or use the <a href="https://wordpress.org/support/plugin/easy-under-construction/">support forum</a>. I will do my the best to resolve your problem as soon as possible. 
Want to say "Thank You"? Please <a href="http://wordpress.org/support/view/plugin-reviews/easy-under-construction?filter=5">Click here</a> to leave a review.

== Installation ==

To install the plugin please follow one of the following options:

Option one:
1. Open WordPress admin, go to Plugins, click Add New
2. Enter "Under construction" in search and press Enter
3. Find the Under construction by Abbas Khalil and click on "Install Now"
4. Activate & open plugin's settings page located in the main WP admin menu "Easy under construction"

Option Two:
1. Upload the plugin to the `/wp-content/plugins/` directory 
2. Activate the plugin through the "Plugins" menu in WordPress dashboard
3. Configure the plugin option from "Easy Under Construction" admin menu located in the main WP admin menu

== Upgrade Notice ==

== Screenshots ==

1. Plugin Option Page
2. Default Under Construction Page
3. Simple Template Example One
4. Simple Template Example Two
5. Simple Template Example Three
6. Customize title, headline, body text or (HTML)
7. HTTP Status Code and User Roles

== Changelog ==

== Frequently Asked Questions ==

== Donations ==
