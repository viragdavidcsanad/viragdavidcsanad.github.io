jQuery(function($) {
	$('#add_current_address_btn').click(function(e) {
		e.preventDefault();
		e.stopPropagation();
		
		$(this).hide();
		$('#loading_current_address').show();
		
		$.get(ajaxurl, {
			action : 'uc_get_ip_address'
		}, function(response) {

			$('#loading_current_address').hide();
			$('#add_current_address_btn').show();
			$('#ip_address').val(response);
		});
	});
	
	$('#301_status').click(function(){
		console.log("selected 301 redirect");
		jQuery('#redirect_panel').show(1000);
	});
	
    $('#displayOption1').click(function(){
		jQuery('#customText').show(1000);
		jQuery('#customHTML').hide(1000);		
	});
	
    $('#displayOption2').click(function(){
		jQuery('#customHTML').show(1000);
		jQuery('#customText').hide(1000);
	});
	
	$('#displayOption0').click(function(){
		jQuery('#customHTML').hide(1000);
		jQuery('#customText').hide(1000);
	});
	
	$('#displayOption4').click(function(){
		jQuery('#customHTML').hide(1000);
		jQuery('#customText').hide(1000);
	});
	$('#displayOption5').click(function(){
		jQuery('#customHTML').hide(1000);
		jQuery('#customText').hide(1000);
	});
	$('#displayOption6').click(function(){
		jQuery('#customHTML').hide(1000);
		jQuery('#customText').hide(1000);
	});
	
	$('#200_status, #503_status').click(function(){
		jQuery('#redirect_panel').hide(1000);
	});
});